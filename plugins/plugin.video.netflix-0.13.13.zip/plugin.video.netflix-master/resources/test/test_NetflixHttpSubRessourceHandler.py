# -*- coding: utf-8 -*-
# Module: NetflixHttpSubRessourceHandler
# Author: asciidisco
# Created on: 11.10.2017
# License: MIT https://goo.gl/5bMj3H

"""Tests for the `NetflixHttpSubRessourceHandler` module"""

import unittest
import mock
from resources.lib.NetflixHttpSubRessourceHandler import NetflixHttpSubRessourceHandler

class NetflixHttpSubRessourceHandlerTestCase(unittest.TestCase):
    pass
